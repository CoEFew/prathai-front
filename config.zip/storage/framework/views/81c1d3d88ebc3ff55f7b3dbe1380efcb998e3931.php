<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="/img/logo/favicon.ico" type="image/x-icon">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous"> -->
    <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" data-auto-replace-svg="nest"></script>
    <title>Meta Prathai</title>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>

<body>
    <div class="">
        <div class="navbar-head my-3">
            <div class="row">
                <div class="col-8">
                    <a class="navbar-brand nav-text text-light" href="#">
                        <img src="/img/logo/logo.png" style="width: 30px;">
                        Meta Prathai
                    </a>
                </div>
                <div class="col nav-textend">
                    <a class="btn rounded-pill text-light" style="background-color: #d09b2c;width:150px;">เข้าสู่ระบบ</a>
                    <a class="btn rounded-pill text-light " style="background-color: #7f8685;width:150px;">สมัครสมาชิก</a>
                    <!-- <a class="btn rounded-pill" style="color:#d09b2c;background-color:#f0ebe1;width:80px;">TH <i class="fas fa-caret-down"></i></a> -->

                    <a class="nav-link dropdown-toggle btn rounded-pill" style="color:#d09b2c;background-color:#f0ebe1;width:80px;" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        TH
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" style="width: 10px;" href="#">TH</a>
                        <a class="dropdown-item" href="#">EN</a>
                    </div>

                </div>
            </div>
        </div>
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li class="rounded-circle" style="width: 10px;height:10px;" data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li class="rounded-circle" style="width: 10px;height:10px;" data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li class="rounded-circle" style="width: 10px;height:10px;" data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="image-banner" alt="First slide">
                        <div class="container">
                            <div class="text-banner">
                                <div class="d-flex text-center">
                                    <div class="col p-4 text-banner">
                                        <img src="/img/logo/logo.png" style="width: 80px;">
                                        <h1 class="text-light" style="font-size: 80px;">Meta Prathai</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="image-banner" alt="Second slide">
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="image-banner" alt="Second slide">
                    </div>
                </div>
            </div>
            <!-- <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a> -->
        </div>
        <div class="row">
            <div class="col-3 ">
                <ul class="col nav flex-column justify-content-center p-5">
                    <li class="nav-item mb-3">
                        <a class="nav-link" style="color: #a9aca7;" href="#home">
                            <img src="/img/svg/home.svg" class="" style="width: 20px;">
                            หน้าแรก </a>
                    </li>
                    <li class="nav-item mb-3">
                        <a class="nav-link " style="color: #a9aca7;" href="#list">
                            <img src="/img/svg/amulet-list.svg" class="" style="width: 20px;">
                            รายการพระเครื่อง</a>
                    </li>
                    <li class="nav-item mb-3">
                        <a class="nav-link" style="color: #a9aca7;" href="#news">
                            <img src="/img/svg/news.svg" class="" style="width: 20px;">
                            ข่าวสาร</a>
                    </li>
                    <li class="nav-item mb-3">
                        <a class="nav-link" style="color: #a9aca7;" href="#contact">
                            <img src="/img/svg/contact.svg" class="" style="width: 20px;">
                            ติดต่อเรา</a>
                    </li>
                    <li class="nav-item mb-5">
                        <a class="nav-link" style="color: #a9aca7;" href="#policy">
                            <img src="/img/svg/policy.svg" class="" style="width: 20px;">
                            นโยบายและเงื่อนไข</a>
                    </li>
                </ul>
                <div class="mt-5 text-center">
                    <img src="/img/png/ads/ad1.png" style="width: 250px;">
                    <img class="mt-4" src="/img/png/ads/ad2.png" style="width: 250px;">
                </div>
            </div>
            <div class="col-6 mt-5">
                <div class="row mb-5">
                    <img src="/img/png/story/story1.png" class="col" style="height: 250px">
                    <img src="/img/png/story/story2.png" class="col" style="height: 250px">
                    <img src="/img/png/story/story3.png" class="col" style="height: 250px">
                    <img src="/img/png/story/story4.png" class="col" style="height: 250px">
                </div>

                <!-- <div class="carousel slide multi-item-carousel " id="theCarousel">
                    <div class="carousel-inner row w-100 mx-auto">
                        <div class="carousel-item active col-md-4">
                            <img src="/img/png/story/story1.png" class="img-fluid mx-auto d-block" style="height: 80%;">
                        </div>
                        <div class="carousel-item col-md-4">
                            <img src="/img/png/story/story2.png" class="img-fluid mx-auto d-block" style="height: 80%;">
                        </div>
                        <div class="carousel-item col-md-4">
                            <img src="/img/png/story/story3.png" class="img-fluid mx-auto d-block" style="height: 80%;">
                        </div>
                        <div class="carousel-item col-md-4">
                            <img src="/img/png/story/story3.png" class="img-fluid mx-auto d-block" style="height: 80%;">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#theCarousel" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#theCarousel" role="button" data-slide="next">
                        <span class="carousel-control-next-icon border rounded-pill shadow" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div> -->

                <div class="bg-light card-new">
                    <div>
                        <div class="container">
                            <br>
                            <h5 class="mb-3">โพสต์ขายทางนี้</h5>
                            <div class="row">
                                <div class="col-1">
                                    <img src="/img/png/profile pic/Mask Group 2.png" class="border border-warning  rounded-circle" style="width: 50px;border-color:#d09a2d;">
                                </div>
                                <div class="col">
                                    <input type="text" class="form-control border w-100" placeholder="คุณกำลังจะขายพระอะไร ?">
                                    <a class="btn rounded-pill text-light mt-3 mb-2" style="background-color: #d09b2c;width:170px;">โพสต์</a>
                                </div>
                            </div>
                            <hr>
                        </div>
                        <ul class="nav nav-tabs nav-justified">
                            <li class="nav-item">
                                <a class="nav-link text-dark" style="font-size: 15px;" href="#">โพสต์ทั้งหมด</a>

                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-dark" style="font-size: 15px;" href="#">ข่าวสาร</a>

                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-dark" style="font-size: 15px;" href="#">ร้านพระที่ติดตาม</a>

                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-dark" style="font-size: 15px;" href="#">พระที่ถูกใจ</a>

                            </li>
                        </ul>
                    </div>
                    <div>
                        <div class="row p-3">
                            <div class="col-6">
                                <div class="row mb-3">
                                    <div class="col-3">
                                        <img src="/img/png/profile pic/Group 1079.png" class="border border-warning  rounded-circle" style="width: 50px;border-color:#d09a2d;">
                                    </div>
                                    <div class="col">
                                        <h5 style="font-size: 13px;">โทน บางแค FC</h5><br>
                                        <h5 style="font-size: 12px;color: #a9aca7;margin-top:-30px; ">@Tone8888</h5><br>
                                        <h5 style="font-size: 12px;color: #a9aca7;margin-top:-30px;">3 ชั่วโมงก่อน</h5>
                                    </div>
                                    <div class="col-3">
                                        <h5 style="font-size: 15px;color: #d09a2d;">ติดตาม</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="d-flex justify-content-end mb-2" style="gap: 10px;">
                                    <img src="/img/svg/save.svg" style="width: 20px;">
                                    <img src="/img/svg/other.svg" style="width: 20px;">
                                </div>
                            </div>
                        </div>
                        <div class="container" style="margin-top: -25px;">
                            <p class="text-primary" style="font-size: 13px;">#โทนบางแคFC</p>
                            <p class="text-primary" style="font-size: 13px;margin-top:-15px;">รับเช่าพระด้วยเงินสดให้ราคายุติธรรม</p>
                            <p style="font-size: 13px;margin-top:-15px;">
                            <h5 style="font-size: 13px;">สวัสดียามเช้าครับ ท่านที่กดรหัสจองเหรียญ ทองคำฝังเพชรเข้ามาทั้ง5พิมพ์ วันนี้เวลา 12.00 น. แอดมินจะเก็บยอดของทุกท่านให้ครบภายในวันนี้ หากมีเพิ่มเติมสามารถใส่รหัส A4-A5-A6-A7-A8 เข้ามาได้เลยนะครับ...</h5>
                            <h5 style="font-size: 13px;color: #d09a2d;margin-top:-10px;">อ่านเพิ่มเติม</h5>
                            </p>
                            <img src="/img/jpeg/Post1.jpg" style="width: 100%;">
                            <div class="row mt-5">
                                <div class="col">
                                    <h5 style="font-size: 13px;color:#a9aca7;"><img src="/img/svg/like.svg" class="rounded-circle" style="width: 15px;background-color:#d09a2d"> 2.9 หมื่น</h5>
                                </div>
                                <div class="col d-flex justify-content-end">
                                    <h5 style="font-size: 13px;color:#a9aca7;">ความคิดเห็น 1.4 พัน รายการ แชร์ 4.7 พัน ครั้ง</h5>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col">
                                    <h5 style="font-size: 13px;color:#a9aca7;"><img src="/img/svg/like.svg" class="" style="width: 15px;"> ถูกใจ</h5>
                                </div>
                                <div class="col d-flex justify-content-center">
                                    <h5 style="font-size: 13px;color:#a9aca7;"><i class="far fa-comment-alt"></i> แสดงความคิดเห็น</h5>
                                </div>
                                <div class="col d-flex justify-content-end">
                                    <h5 style="font-size: 13px;color:#a9aca7;"><i class="far fa-share-square"></i> แชร์</h5>
                                </div>
                            </div>
                            <hr style="margin-top:0px;">
                            <h5 style="font-size: 13px;color: #d09a2d;margin-top:-5px;">ความคิดเห็นก่อนหน้า</h5>
                            <div class="row">
                                <div class="col-1">
                                    <img src="/img/png/profile pic/Group 1084.png" class="border border-warning  rounded-circle" style="border-color:#d09a2d;">
                                </div>
                                <div class="col">
                                    <h5 style="font-size: 13px;color: #d09a2d;">ออย' เด็กดื้อ</h5><br>
                                    <h5 style="font-size: 12px;color: #a9aca7;margin-top:-30px;">2 ชั่วโมงก่อน</h5>
                                    <h5 style="font-size: 13px;">ผมจะปล่อยหลวงพ่อคง แต่ติดต่อไม่ได้ครับ</h5>
                                </div>
                            </div>
                            <hr>
                        </div>
                        <div class="row p-3">
                            <div class="col-6">
                                <div class="row mb-3">
                                    <div class="col-3">
                                        <img src="/img/png/profile pic/Group 1079.png" class="border border-warning  rounded-circle" style="width: 50px;border-color:#d09a2d;">
                                    </div>
                                    <div class="col">
                                        <h5 style="font-size: 13px;">โทน บางแค FC</h5><br>
                                        <h5 style="font-size: 12px;color: #a9aca7;margin-top:-30px; ">@Tone8888</h5><br>
                                        <h5 style="font-size: 12px;color: #a9aca7;margin-top:-30px;">8 ชั่วโมงก่อน</h5>
                                    </div>
                                    <div class="col-3">
                                        <h5 style="font-size: 15px;color: #d09a2d;">ติดตาม</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                            <div class="d-flex justify-content-end mb-2" style="gap: 10px;">
                                    <img src="/img/svg/save.svg" style="width: 20px;">
                                    <img src="/img/svg/other.svg" style="width: 20px;">
                                </div>
                            </div>
                        </div>
                        <div class="container" style="margin-top: -25px;">
                            <p class="text-primary" style="font-size: 13px;">#โทนบางแคFC</p>
                            <p class="text-primary" style="font-size: 13px;margin-top:-15px;">รับเช่าพระด้วยเงินสดให้ราคายุติธรรม</p>
                            <p style="font-size: 13px;margin-top:-15px;">
                            <h5 style="font-size: 13px;">สวัสดียามเช้าครับ ท่านที่กดรหัสจองเหรียญ ทองคำฝังเพชรเข้ามาทั้ง5พิมพ์ วันนี้เวลา 12.00 น. ...</h5>
                            <h5 style="font-size: 13px;color: #d09a2d;margin-top:-10px;">อ่านเพิ่มเติม</h5>
                            </p>
                        </div>
                    </div>


                </div>
            </div>
            <div class="col-3 p-5">
                <div class="mt-5">
                    <h5 style="font-size: 15px;">วิดีโอถ่ายทอดสด</h5>
                    <div class="d-flex justify-content-center">
                        <img src="/img/png/profile pic/Group 1054.png" style="width: 250px;">
                    </div>
                    <a class="btn w-100 mt-2" style="background-color:#cfcdce;color: #a9aca7;">ตารางเวลาถ่ายทอดสดวิดีโอ</a>
                    <hr class="mt-4 rounded" style="border-width: 2px;background-color:#c3c1bd;">
                </div>
                <div>
                    <h5 style="font-size: 15px;">ตามหาพระ</h5>
                    <form>
                        <div class="form-row">
                            <div class="col-6 mb-2">
                                <input type="text" class="form-control rounded-pill" placeholder="ชื่อพระเครื่อง">
                            </div>
                            <div class="col-6 mb-2">
                                <input type="text" class="form-control rounded-pill" placeholder="ชื่อร้านพระ">
                            </div>
                            <div class="col-6 mb-2">
                                <select class="custom-select my-1 mr-sm-2 rounded-pill" id="inlineFormCustomSelectPref">
                                    <option selected>ราคา</option>
                                    <option value="1">100-999</option>
                                    <option value="2">1000-1499</option>
                                    <option value="3">1500-5000</option>
                                </select>
                            </div>
                            <div class="col-6 mb-2">
                                <select class="custom-select my-1 mr-sm-2 rounded-pill" id="inlineFormCustomSelectPref">
                                    <option selected>จังหวัด</option>
                                    <option value="1">กรุงเทพ</option>
                                    <option value="2">ระนอง</option>
                                    <option value="3">ระยอง</option>
                                    <option value="3">ยะลา</option>
                                </select>
                            </div>
                            <div class="col-12 mb-2">
                                <select class="custom-select my-1 mr-sm-2 rounded-pill" id="inlineFormCustomSelectPref">
                                    <option selected>เลือกจากพระเภทพระ</option>
                                    <option value="1">พระบูชา</option>
                                    <option value="2">พระกรุ</option>
                                    <option value="3">เครื่องราง</option>
                                    <option value="4">พระรูปหล่อ</option>
                                    <option value="5">พระพระปิดตา</option>
                                    <option value="6">เหรียญหล่อ</option>
                                    <option value="7">พระกรึ่ง พระชัย</option>
                                    <option value="8">พระอื่นๆ</option>
                                </select>
                            </div>
                        </div>
                    </form>
                    <button class="btn text-light rounded-pill col-12" style="background-color: #d09a2d;">ค้นหาพระ</button>
                    <hr class="mt-4 rounded" style="border-width: 2px;background-color:#c3c1bd;">
                </div>
                <div>
                    <h5 class="mt-3 mb-3" style="font-size: 15px;">ร้านที่คุณอาจจะถูกใจ</h5>
                    <div class="row mb-3">
                        <div class="col-3">
                            <img src="/img/png/profile pic/Group 1058.png" class="border border-warning  rounded-circle" style="width: 50px;border-color:#d09a2d;">

                        </div>
                        <div class="col">
                            <h5 style="font-size: 13px;">บอย ท่าพระจันทร์ FC</h5>
                            <h5 style="font-size: 12px;color: #a9aca7;">@boythaphrachan</h5>
                        </div>
                        <div class="col-3">
                            <h5 style="font-size: 15px;color: #d09a2d;">ติดตาม</h5>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <img src="/img/png/profile pic/Group 1060.png" class="border border-warning  rounded-circle" style="width: 50px;border-color:#d09a2d;">

                        </div>
                        <div class="col">
                            <h5 style="font-size: 13px;">ร้านพระเครื่องนพเก้า</h5>
                            <h5 style="font-size: 12px;color: #a9aca7;">@Noppagao168</h5>
                        </div>
                        <div class="col-3">
                            <h5 style="font-size: 15px;color: #d09a2d;">ติดตาม</h5>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-3">
                            <img src="/img/png/profile pic/Group 1062.png" class="border border-warning  rounded-circle" style="width: 50px;border-color:#d09a2d;">

                        </div>
                        <div class="col">
                            <h5 style="font-size: 13px;">พระเครื่องเรื่องสนุก</h5>
                            <h5 style="font-size: 12px;color: #a9aca7;">@delightfulamulets</h5>
                        </div>
                        <div class="col-3">
                            <h5 style="font-size: 15px;color: #d09a2d;">ติดตาม</h5>
                        </div>
                    </div>
                    <h5 style="font-size: 15px;color: #d09a2d;">ดูเพิ่มเติม</h5>
                    <hr class="mt-4 rounded" style="border-width: 2px;background-color:#c3c1bd;">
                </div>
                <div>
                    <h5 class="mt-3 mb-4" style="font-size: 15px;">พระยอดนิยม</h5>
                    <h5 class="mb-4" style="font-size: 15px;color: #d09a2d;">#พระบูชา</h5>
                    <h5 class="mb-4" style="font-size: 15px;color: #d09a2d;">#เครื่องราง</h5>
                    <h5 class="mb-4" style="font-size: 15px;color: #d09a2d;">#รูปหล่อ</h5>
                    <h5 style="font-size: 15px;color: #d09a2d;">ดูเพิ่มเติม</h5>
                    <hr class="mt-4 rounded" style="border-width: 2px;background-color:#c3c1bd;">
                </div>
            </div>
        </div>
    </div>

</body>

</html><?php /**PATH D:\xampp\htdocs\prathai-project\resources\views/index.blade.php ENDPATH**/ ?>